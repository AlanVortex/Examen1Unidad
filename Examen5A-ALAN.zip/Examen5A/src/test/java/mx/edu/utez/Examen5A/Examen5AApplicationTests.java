package mx.edu.utez.Examen5A;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen5AApplicationTests {

	@Test
	void contextLoads() {
	}

}
