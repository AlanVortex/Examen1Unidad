package mx.edu.utez.Examen5A.service;

import mx.edu.utez.Examen5A.model.dto.DtoPerson;
import mx.edu.utez.Examen5A.model.entity.BeanPerson;

import java.util.List;

public interface IPerson {
BeanPerson save (DtoPerson dtoPerson);
BeanPerson findById(Integer id);
List<BeanPerson> findAll();
void delete (BeanPerson beanPerson);
}
