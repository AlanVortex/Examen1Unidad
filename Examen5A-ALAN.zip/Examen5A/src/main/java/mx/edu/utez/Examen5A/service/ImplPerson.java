package mx.edu.utez.Examen5A.service;

import lombok.AllArgsConstructor;
import mx.edu.utez.Examen5A.model.dao.DaoPerson;
import mx.edu.utez.Examen5A.model.dto.DtoPerson;
import mx.edu.utez.Examen5A.model.entity.BeanPerson;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Random;

@AllArgsConstructor
@Service
public class ImplPerson implements IPerson{

    private final DaoPerson daoPerson;
    @Transactional
    @Override

    public BeanPerson save(DtoPerson dtoPerson) {

        StringBuilder curp = new StringBuilder();
        String primerApellido = dtoPerson.getApellido1().toUpperCase();
        String segundoApellido = dtoPerson.getApellido2().toUpperCase();
        String nombre = dtoPerson.getNombre().toUpperCase();
        curp.append(primerApellido.toCharArray()[0]);

        if (primerApellido.toCharArray()[0] == 'A' || primerApellido.toCharArray()[0] == 'E' ||
                primerApellido.toCharArray()[0] == 'I' || primerApellido.toCharArray()[0] == 'O' ||
                primerApellido.toCharArray()[0] == 'U') {
            for (int i = 1; i < primerApellido.length(); i++) {
                if (primerApellido.charAt(i) == 'A' || primerApellido.charAt(i) == 'E' ||
                        primerApellido.charAt(i) == 'I' || primerApellido.charAt(i) == 'O' ||
                        primerApellido.charAt(i) == 'U') {
                    curp.append(primerApellido.charAt(i));
                    break;
                }
            }
        } else {
            for (char letra: primerApellido.toCharArray()) {
                if (letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' || letra == 'U') {
                    curp.append(letra);
                    break;
                }
            }
        }

        curp.append(segundoApellido.toCharArray()[0]);
        curp.append(dtoPerson.getNombre().toCharArray()[0]);
        curp.append(dtoPerson.getFecha_nacimiento().toCharArray()[dtoPerson.getFecha_nacimiento().length() - 2]);
        curp.append(dtoPerson.getFecha_nacimiento().toCharArray()[dtoPerson.getFecha_nacimiento().length() - 1]);
        curp.append(dtoPerson.getFecha_nacimiento().toCharArray()[dtoPerson.getFecha_nacimiento().length() - 7]);
        curp.append(dtoPerson.getFecha_nacimiento().toCharArray()[dtoPerson.getFecha_nacimiento().length() - 6]);
        curp.append(dtoPerson.getFecha_nacimiento().toCharArray()[0]);
        curp.append(dtoPerson.getFecha_nacimiento().toCharArray()[1]);


        curp.append(dtoPerson.getGenero().toUpperCase().toCharArray()[0]);
        curp.append(dtoPerson.getEstado_nacimiento().toUpperCase());


        for (int i = 1; i < segundoApellido.length(); i++) {
            if (segundoApellido.toCharArray()[i] != 'A' && segundoApellido.toCharArray()[i] != 'E'
                    && segundoApellido.toCharArray()[i] != 'I' && segundoApellido.toCharArray()[i] != 'O'
                    && segundoApellido.toCharArray()[i] != 'U') {
                curp.append(segundoApellido.toCharArray()[i]);
                break;
            }
        }


        for (int i = 1; i < nombre.length(); i++) {
            if (nombre.toCharArray()[i] != 'A' && nombre.toCharArray()[i] != 'E'
                    && nombre.toCharArray()[i] != 'I' && nombre.toCharArray()[i] != 'O'
                    && nombre.toCharArray()[i] != 'U') {
                curp.append(nombre.toCharArray()[i]);
                break;
            }
        }

        Random random = new Random();
        curp.append(random.nextInt(1, 10));
        curp.append(random.nextInt(1, 10));

        BeanPerson dtoPersons = BeanPerson.builder()
                .id_personas(dtoPerson.getId())
                .nombre(dtoPerson.getNombre())
                .apellido1(dtoPerson.getApellido1())
                .apellido2(dtoPerson.getApellido2())
                .fecha_nacimiento(dtoPerson.getFecha_nacimiento())
                .estado_nacimiento(dtoPerson.getEstado_nacimiento())
                .genero(dtoPerson.getGenero())
                .curp(curp.toString())
                .build();
        return daoPerson.save(dtoPersons);
    }
    @Transactional(readOnly = true)
    @Override
    public BeanPerson findById(Integer id) {
        return daoPerson.findById(id).orElse(null);
    }

    @Transactional
    @Override
    public List<BeanPerson> findAll() {
        return(List<BeanPerson>) daoPerson.findAll();
    }

    @Transactional
    @Override
    public void delete(BeanPerson dtoPersons) {
        daoPerson.delete(dtoPersons);
    }
}
