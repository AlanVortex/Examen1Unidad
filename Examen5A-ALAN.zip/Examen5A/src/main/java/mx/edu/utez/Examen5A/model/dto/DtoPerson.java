package mx.edu.utez.Examen5A.model.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class DtoPerson {
    private Integer id;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String fecha_nacimiento;
    private String estado_nacimiento;
    private String genero;
    private String curp;
}
