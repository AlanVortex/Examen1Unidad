package mx.edu.utez.Examen5A.model.dao;

import mx.edu.utez.Examen5A.model.entity.BeanPerson;
import org.springframework.data.repository.CrudRepository;

public interface DaoPerson extends CrudRepository<BeanPerson, Integer> {
}
