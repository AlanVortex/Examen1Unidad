package mx.edu.utez.Examen5A.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@Entity
@Table(name = "personas")
public class BeanPerson {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_personas")
    private Integer id_personas;
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "apellido1")
    private String apellido1;
    @Column(name = "apellido2")
    private String apellido2;
    @Column(name = "fecha_nacimiento")
    private String fecha_nacimiento;
    @Column(name = "estado_nacimiento")
    private String estado_nacimiento;
    @Column(name = "genero")
    private String genero;
    @Column(name = "curp")
    private String curp;
}
