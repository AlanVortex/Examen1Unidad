package mx.edu.utez.Examen5A;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen5AApplication {

	public static void main(String[] args) {
		SpringApplication.run(Examen5AApplication.class, args);
	}

}
