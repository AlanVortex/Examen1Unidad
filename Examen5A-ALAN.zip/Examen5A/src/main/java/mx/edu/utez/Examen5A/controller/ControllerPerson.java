package mx.edu.utez.Examen5A.controller;

import lombok.AllArgsConstructor;
import mx.edu.utez.Examen5A.model.dto.DtoPerson;
import mx.edu.utez.Examen5A.model.entity.BeanPerson;
import mx.edu.utez.Examen5A.service.ImplPerson;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v1")
public class ControllerPerson {

    private final ImplPerson personService;

    @PostMapping("/persons")
    public DtoPerson create(@RequestBody DtoPerson dtoPerson){
        BeanPerson personSave = personService.save(dtoPerson);
        return dtoPerson.builder()
                .id(personSave.getId_personas())
                .nombre(personSave.getNombre())
                .apellido1(personSave.getApellido1())
                .apellido2(personSave.getApellido2())
                .fecha_nacimiento(personSave.getFecha_nacimiento())
                .estado_nacimiento(personSave.getEstado_nacimiento())
                .genero(personSave.getGenero())
                .curp(personSave.getCurp())
                .build();
    }

    @PutMapping("/persons")
    public DtoPerson update(@RequestBody DtoPerson dtoPerson){
        BeanPerson personUpdate = personService.save(dtoPerson);
        return dtoPerson.builder()
                .id(personUpdate.getId_personas())
                .nombre(personUpdate.getNombre())
                .apellido1(personUpdate.getApellido1())
                .apellido2(personUpdate.getApellido2())
                .fecha_nacimiento(personUpdate.getFecha_nacimiento())
                .estado_nacimiento(personUpdate.getEstado_nacimiento())
                .genero(personUpdate.getGenero())
                .curp(personUpdate.getCurp())
                .build();
    }

    @DeleteMapping("persons/{id}")
    public ResponseEntity<?> delete(@PathVariable Integer id) {
        Map<String, Object> response = new HashMap<>();
        try {
            BeanPerson person = personService.findById(id);
            personService.delete(person);
            return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
        } catch (DataAccessException ex) {
            response.put("msj", ex.getMessage());
            response.put("Person", null);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("persons/{id}")
    public BeanPerson showById(@PathVariable Integer id){
        try{
            return personService.findById(id);
        } catch (DataAccessException dae) {
            throw new RuntimeException("Error en Base de Datos: ", dae);
        } catch (Exception ex) {
            throw new RuntimeException("Error al obtener la persona: ", ex);
        }
    }

    @GetMapping("/persons")
    public List<BeanPerson> findAll(){
        try{
            return personService.findAll();
        } catch (DataAccessException dae) {
            throw new RuntimeException("Error en Base de Datos: ", dae);
        } catch (Exception ex) {
            throw new RuntimeException("Error al obtener la persona: ", ex);
        }
    }
}
